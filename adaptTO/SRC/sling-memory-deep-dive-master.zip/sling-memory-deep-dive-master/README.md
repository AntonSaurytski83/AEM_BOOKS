# sling-memory-deep-dive
Talk materials for adaptTo 2018 presentation https://adapt.to/2018/en/schedule/sling-memory-deep-dive.html
