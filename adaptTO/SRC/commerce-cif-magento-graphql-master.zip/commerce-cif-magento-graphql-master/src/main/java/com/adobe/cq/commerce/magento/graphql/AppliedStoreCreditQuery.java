/*******************************************************************************
 *
 *    Copyright 2020 Adobe. All rights reserved.
 *    This file is licensed to you under the Apache License, Version 2.0 (the "License");
 *    you may not use this file except in compliance with the License. You may obtain a copy
 *    of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 *    Unless required by applicable law or agreed to in writing, software distributed under
 *    the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR REPRESENTATIONS
 *    OF ANY KIND, either express or implied. See the License for the specific language
 *    governing permissions and limitations under the License.
 *
 ******************************************************************************/

package com.adobe.cq.commerce.magento.graphql;

import com.shopify.graphql.support.AbstractQuery;
import com.shopify.graphql.support.Fragment;

/**
 * Applied and current balance
 */
public class AppliedStoreCreditQuery extends AbstractQuery<AppliedStoreCreditQuery> {
    AppliedStoreCreditQuery(StringBuilder _queryBuilder) {
        super(_queryBuilder);
    }

    /**
     * Applied store credit balance to the current cart
     */
    public AppliedStoreCreditQuery appliedBalance(MoneyQueryDefinition queryDef) {
        startField("applied_balance");

        _queryBuilder.append('{');
        queryDef.define(new MoneyQuery(_queryBuilder));
        _queryBuilder.append('}');

        return this;
    }

    /**
     * Current balance remaining on store credit
     */
    public AppliedStoreCreditQuery currentBalance(MoneyQueryDefinition queryDef) {
        startField("current_balance");

        _queryBuilder.append('{');
        queryDef.define(new MoneyQuery(_queryBuilder));
        _queryBuilder.append('}');

        return this;
    }

    /**
     * Indicates whether store credits are enabled. If the feature is disabled, then the current balance
     * will not be returned
     */
    public AppliedStoreCreditQuery enabled() {
        startField("enabled");

        return this;
    }

    /**
     * Creates a GraphQL "named" fragment with the specified query type definition.
     * The generics nature of fragments ensures that a fragment can only be used at the right place in the GraphQL request.
     * 
     * @param name The name of the fragment, must be unique for a given GraphQL request.
     * @param queryDef The fragment definition.
     * @return The fragment of a given generics type.
     */
    public static Fragment<AppliedStoreCreditQuery> createFragment(String name, AppliedStoreCreditQueryDefinition queryDef) {
        StringBuilder sb = new StringBuilder();
        queryDef.define(new AppliedStoreCreditQuery(sb));
        return new Fragment<>(name, "AppliedStoreCredit", sb.toString());
    }

    /**
     * Adds a <code>AppliedStoreCreditQuery</code> fragment reference at the current position of the query.
     * For example for a fragment named <code>test</code>, calling this method will add the
     * reference <code>...test</code> in the query. For GraphQL types implementing an interface, there
     * will be some similar methods using the Query type of each implemented interface.
     * 
     * @param fragment The fragment to reference.
     */
    public AppliedStoreCreditQuery addFragmentReference(Fragment<AppliedStoreCreditQuery> fragment) {
        startField("..." + fragment.getName());
        return this;
    }
}
