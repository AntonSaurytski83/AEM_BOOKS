---
Colors
---

This is default documentation for colors