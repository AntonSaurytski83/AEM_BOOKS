mvn package -Dvault.unpack=true wcmio-content-package:download
