define(['publish/ui',
        'publish/media',
        'publish/social',
        'publish/syntax'], function(){

    'use strict';

});