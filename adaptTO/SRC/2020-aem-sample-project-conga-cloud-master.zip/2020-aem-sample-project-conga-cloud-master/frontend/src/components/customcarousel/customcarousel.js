import $ from "jquery";
import "bootstrap/js/dist/carousel";

export default () => {
  $(".carousel").carousel();
};
