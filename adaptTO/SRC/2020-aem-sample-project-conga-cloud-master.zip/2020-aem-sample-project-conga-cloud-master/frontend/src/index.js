import $ from "jquery";
import CustomCarousel from "./components/customcarousel/customcarousel";

// Document Ready
$(() => {
  CustomCarousel();
});
