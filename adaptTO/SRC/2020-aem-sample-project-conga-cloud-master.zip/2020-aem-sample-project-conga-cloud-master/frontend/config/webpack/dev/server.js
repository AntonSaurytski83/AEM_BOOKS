export const devServer = {
  devServer: {
    compress: true,
    port: 9000,
    contentBase: "./public"
  }
};
