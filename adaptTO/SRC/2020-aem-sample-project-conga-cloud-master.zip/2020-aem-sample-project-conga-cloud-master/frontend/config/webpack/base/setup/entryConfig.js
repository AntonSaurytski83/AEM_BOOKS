import path from "path";

export const entry = {
  app: [path.resolve("src/index.js"), path.resolve("src/index.scss")]
};
