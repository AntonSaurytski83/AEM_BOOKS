export const prodConfig = {
  devtool: "source-map",
  stats: "errors-only",
  bail: true
};
