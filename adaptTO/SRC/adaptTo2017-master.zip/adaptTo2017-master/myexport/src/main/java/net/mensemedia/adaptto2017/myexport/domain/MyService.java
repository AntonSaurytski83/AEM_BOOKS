package net.mensemedia.adaptto2017.myexport.domain;
public interface MyService {
    void process(ProcessingContext ctx);
}
