package net.mensemedia.adaptto2017.myexport.domain;
public interface Exporter {
    void export(MyExportData data);
}
