package net.mensemedia.adaptto2017.myexport.domain;
public class ValidationException extends Exception {
    public ValidationException(final String message) {
        super(message);
    }
}
