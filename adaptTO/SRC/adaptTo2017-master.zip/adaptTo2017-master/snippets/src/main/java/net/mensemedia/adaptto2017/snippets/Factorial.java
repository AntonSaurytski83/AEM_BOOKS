package net.mensemedia.adaptto2017.snippets;
interface Factorial {
    long fac(final int n);
}
