package net.mensemedia.adaptto2017.commons.testing;
/**
 * Class RuntimeReflectionException.
 */
public class RuntimeReflectionException extends RuntimeException {
    public RuntimeReflectionException(final Exception e) {
        super(e);
    }
}
