package de.joerghoh.aem.kafka.impl.producer;

public interface Producer {

}
