package de.joerghoh.aem.kafka.consumer;

public class IncompleteKafkaConfigurationException extends Exception {

	
	public IncompleteKafkaConfigurationException (String message) {
		super (message);
	}
	
}
