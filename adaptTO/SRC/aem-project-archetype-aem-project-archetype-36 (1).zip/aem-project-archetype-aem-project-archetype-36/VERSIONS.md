# Archetype Historical Supported AEM Versions

See below a list of supported AEM versions of historical archetype versions:

Archetype Version   | AEM Version
--------------------|-------------
7                   | 6.0 or newer
8                   | 6.0 or newer
9                   | 6.0 or newer
10                  | 6.0 or newer
11                  | 6.2 or newer
12                  | 6.3 or newer
14                  | 6.4, 6.3 + SP2
15                  | 6.4, 6.3 + SP2
16                  | 6.4, 6.3 + SP2
13                  | 6.4, 6.3 + SP2
17                  | 6.4, 6.3 + SP2
18                  | 6.5, 6.4, 6.3 + SP3
19                  | 6.5, 6.4, 6.3 + SP3
20, 21, 22          | 6.5, 6.4, 6.3 + SP3
23                  | 6.5, 6.4, 6.3 + SP3, AEM as a Cloud Service
24, 25, 26, 27      | 6.5.5, 6.4.8.1, AEM as a Cloud Service
28, 30, 31, 32, 33, 34, 35, 36  | 6.5.7, AEM as a Cloud Service
