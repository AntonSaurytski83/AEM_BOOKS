# Repository Structure Package

This module contains the repository structure package which is required by AEM as a Cloud Service deployments. 

For a more information about this package and how to customize it please have a look to the [official documentation](https://docs.adobe.com/content/help/en/experience-manager-cloud-service/implementing/developing/repository-structure-package.html).