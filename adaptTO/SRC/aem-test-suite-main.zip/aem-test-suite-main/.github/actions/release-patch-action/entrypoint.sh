#!/bin/bash
git config --global user.email "shineworks@shinesolutions.com"
git config --global user.name "Shine Works"
make release-patch