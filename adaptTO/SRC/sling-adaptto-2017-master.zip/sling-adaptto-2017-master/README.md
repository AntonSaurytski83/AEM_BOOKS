# sling-adaptto-2017
Code for my adaptTo() 2017 talk
