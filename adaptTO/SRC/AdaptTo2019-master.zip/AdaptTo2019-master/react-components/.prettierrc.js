/**
 * default prettier config
 * which automatically gets selected
 * by prettier plugins for all main editors
 * and is used to lint this project.
 */

module.exports = {
  singleQuote: true,
  trailingComma: 'none'
}
