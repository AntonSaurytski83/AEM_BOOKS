@aQute.bnd.annotation.Version("1.0.0")
package biz.netcentric.aem.tools.acvalidator.api;