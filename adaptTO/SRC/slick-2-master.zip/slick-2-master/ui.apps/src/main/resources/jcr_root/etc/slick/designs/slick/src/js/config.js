require.config({
  paths : { 'handlebars' : '/../../libs/js/handlebars' }
});