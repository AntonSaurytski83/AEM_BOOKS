define(function () {
    'use strict';

    /**
     * Highlight.js
     */
    window.hljs.initHighlightingOnLoad();
});