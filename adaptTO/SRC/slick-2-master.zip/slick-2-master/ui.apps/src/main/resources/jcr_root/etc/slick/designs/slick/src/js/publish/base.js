define(['publish/ui',
        'publish/media',
        'publish/social',
        'publish/syntax',
        'publish/ui',
        'publish/comments/list',
        'publish/comments/create'], function () {

    'use strict';

});