/*global define */
define(['author/messaging',
        'author/toggle',
        'author/sectionNavigation',
        'author/userManager',
        'author/onBoarding',
        'author/itemEdit',
        'author/itemDelete',
        'author/itemExpand',
        'author/media',
        'author/settings'], function () {
    'use strict';
});