require(['publish/base'], function() {
  'use strict';
});