require([
    'handlebars',
    'author/base'
], function () {
    'use strict';
});