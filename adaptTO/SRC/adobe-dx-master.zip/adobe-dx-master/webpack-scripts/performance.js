module.exports = { hints: false };
