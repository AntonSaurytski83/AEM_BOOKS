// Ignore for code coverage
/* istanbul ignore file */

module.exports = require('babel-jest').createTransformer({
    rootMode: 'upward',
});
