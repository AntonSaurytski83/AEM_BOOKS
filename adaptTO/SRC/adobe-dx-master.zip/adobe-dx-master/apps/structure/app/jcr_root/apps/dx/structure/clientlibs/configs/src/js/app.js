import GradientConfig from './GradientConfig';

// Consumer Code
window.dx.configManager.registerApp('dx-gradient', 'Dx Gradient', GradientConfig);
