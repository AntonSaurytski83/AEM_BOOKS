# Releasing

## Prerequesites
- to do a release, you must know what module, with what [version](https://semver.org/) you should use.
- to prepare or perform a adobe-dx release, you must have write access to that repository, and a [token that has write access to it](https://help.github.com/en/packages/using-github-packages-with-your-projects-ecosystem/configuring-apache-maven-for-use-with-github-packages#authenticating-to-github-packages)
- each and every release must be signed, so you need to have GPG key (https://help.github.com/en/github/authenticating-to-github/generating-a-new-gpg-key)
- once done, you can add in your `~/.m2/settings.xml` following profile
```
...
<profiles>
    <profile>
        <id>dx-release</id>
        <properties>
            <gpg.keyname><!--your public key--></gpg.keyname>
            <gpg.passphrase><!--encrypted gpg passphrase--></gpg.passphrase>
        </properties>
    </profile>
</profiles>
```
- please also upload your public key to some key server e.g. `gpg --keyserver keys.openpgp.org --send-key <keyid>`
- note that depending on your OS, you may hit https://issues.apache.org/jira/browse/MGPG-59 which is plugin's gpg agent trying 
to access IO. Message being something like 

```gpg: signing failed: Inappropriate ioctl for device```

As proposed in the ticket, in order to counter balance this, pls execute following command _before_ preparing release:

```gpg -u <your key's email> --use-agent --armor --detach-sign --output $(mktemp) pom.xml```

For mac users, you can fix it by installing [pinentry-mac](https://github.com/Homebrew/homebrew-core/issues/14737#issuecomment-309547412)
## Release
### pre-checks
1. check that your local is up to date with origin,
2. (optional) check that a release would work by running a dry run release
```mvn release:prepare -Pdx-release -DdryRun=true```
if things looks good to you, you can rollback all changes
```mvn release:rollback -Pdx-release -DdryRun=true```
#### pre-checks specific per artifact
- `core` ensure the version you are about to release points to a released `testing` artifact

- `testing-extensions` ensure the version you are about to release points to released `testing` and `core` artifacts

- `admin`, `structure` and `content` ensure the version you are about to release points to released `core` and `testing-extensions` artifacts

### commands
1. prepare the release 
```mvn release:prepare```
2. perform the release
```mvn release:perform -Pdx-release```
you can have that command run several times in case of a failure that is fixable
5. (if anything goes wrong) rollback the release
```mvn release:rollback -Pdx-release``` 
6. (if things went well) go to https://repo1.maven.org/maven2/com/adobe/dx 
and check there released artifacts. Eventually do an announce / gh release if important one.
