# Testing

adding utilities as abstract classes for testing across the repository

- AbstractTest: for standard test,
- AbstractRequestModelTest: for testing sling models adapting from requests
