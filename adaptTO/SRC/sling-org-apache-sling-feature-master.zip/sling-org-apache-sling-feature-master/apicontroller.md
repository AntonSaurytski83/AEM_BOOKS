# API Controller

This documentation has moved to the [API Region Extension](https://github.com/apache/sling-org-apache-sling-feature-extension-apiregions/blob/master/docs/api-regions.md)
