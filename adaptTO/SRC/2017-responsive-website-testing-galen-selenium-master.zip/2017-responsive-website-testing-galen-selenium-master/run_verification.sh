#!/bin/bash

mvn clean install -Pverify
