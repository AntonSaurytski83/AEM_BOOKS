#!/bin/bash

mvn clean install -Pverify -Dgalenium.ignoreVerification=true
