adaptTo() 2017 - Responsive Website Testing with Galen and Selenium
===================================================================

Code samples for talk at adaptTo() 2017 in Berlin:<br/>
https://adapt.to/2017/en/schedule/responsive-website-testing-with-galen-and-selenium.html

Required:
1. [wcm-io-samples](https://github.com/wcm-io/wcm-io-samples) deployed to AEM instance running on localhost:4502
2. Chrome and Firefox

Run:
1. run_sampling.sh
2. use_samples_from_last_run.sh
3. run_verification.sh
4. run_ci.sh
