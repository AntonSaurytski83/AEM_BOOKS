package com.composum.sling.clientlibs.processor;

import com.composum.sling.clientlibs.service.ClientlibRenderer;

/** Interface for renderers of various link types. */
public interface LinkRenderer extends ClientlibRenderer {
}
