package com.composum.sling.clientlibs.handle;

import org.apache.sling.api.resource.Resource;

public class ImageHandle extends FileHandle {

    public ImageHandle(Resource resource) {
        super(resource);
    }
}
