package com.composum.sling.clientlibs.processor;

import com.composum.sling.clientlibs.service.ClientlibProcessor;
import com.composum.sling.clientlibs.service.ClientlibRenderer;

public interface JavascriptProcessor extends ClientlibProcessor, ClientlibRenderer {
}
