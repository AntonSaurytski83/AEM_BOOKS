package com.composum.sling.clientlibs.processor;

import com.composum.sling.clientlibs.service.ClientlibProcessor;

public interface GzipProcessor extends ClientlibProcessor {
}
