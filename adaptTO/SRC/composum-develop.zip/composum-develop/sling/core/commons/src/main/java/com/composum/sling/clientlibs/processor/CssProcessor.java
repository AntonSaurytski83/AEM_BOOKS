package com.composum.sling.clientlibs.processor;

import com.composum.sling.clientlibs.service.ClientlibProcessor;
import com.composum.sling.clientlibs.service.ClientlibRenderer;

public interface CssProcessor extends ClientlibProcessor, ClientlibRenderer {
}
