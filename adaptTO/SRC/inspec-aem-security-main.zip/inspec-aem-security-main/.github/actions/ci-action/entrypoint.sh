#!/bin/bash
make ci
