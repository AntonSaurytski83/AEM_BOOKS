@RequireConfigurator
package net.lr.tasklist.resource;

import org.osgi.service.configurator.annotations.RequireConfigurator;