[<img src="https://sling.apache.org/res/logos/sling.png"/>](https://sling.apache.org)

# Apache Sling Content-Package Archetype

This module is part of the [Apache Sling](https://sling.apache.org) project.

Maven archetype for a Jackrabbit FileVault content package
