mvn clean package wcmio-content-package:install
