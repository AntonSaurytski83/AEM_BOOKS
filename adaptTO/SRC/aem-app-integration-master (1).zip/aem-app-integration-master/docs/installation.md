Demo Content Package
==========================

This is the simplest way to test the AEM App-Integration locally. 

 - Download the pacakge

Install Package
###################


--- xml

<maven-dependency>

