this is about design
![image-title-here](img/Application%20Integration%20Main%20Classes.svg){:class="img-responsive"}