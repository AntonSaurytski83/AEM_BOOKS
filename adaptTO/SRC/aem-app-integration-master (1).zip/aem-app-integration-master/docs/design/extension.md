Extension Points
==============================


Context Provider
-------------------



Processing Tasks
--------------------------




Custom AEM Components
-------------------------------



