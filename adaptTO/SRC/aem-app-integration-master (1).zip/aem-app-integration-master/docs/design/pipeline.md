Processing Pipeline
==================================


A **Processing Pipeline** is a highly configurable, almost programmable sequence of processing tasks. 

**Input:**
 
- Reference (to a resource)

**Output:**

- Resource (processed)
- Error messages and/or warnings
- Properties (e.g. HTTP headers)
- List of referenced resources


Configuration
--------------------------

### Task



### Switch



