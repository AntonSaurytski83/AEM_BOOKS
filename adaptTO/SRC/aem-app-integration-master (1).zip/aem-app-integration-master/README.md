![GitHub Workflow Status](https://img.shields.io/github/workflow/status/alberndt/aem-app-integration/Java%20CI%20with%20Maven) [![Quality Gate Status](https://sonarcloud.io/api/project_badges/measure?project=alberndt_aem-app-integration&metric=alert_status)](https://sonarcloud.io/dashboard?id=alberndt_aem-app-integration)

# AEM Application Integration

This is a framework for  integrating external web-applications into AEM (Adobe Experience Manager)

Currently, work in progress!!!


[AEM App-Integration Github Server Pages](https://alberndt.github.io/aem-app-integration/)



# Table of Contents <!-- omit in toc -->

- [AEM Application Integration](#aem-application-integration)

