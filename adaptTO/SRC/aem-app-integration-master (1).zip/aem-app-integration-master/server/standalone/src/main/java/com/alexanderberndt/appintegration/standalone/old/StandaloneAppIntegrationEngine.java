package com.alexanderberndt.appintegration.standalone.old;

public class StandaloneAppIntegrationEngine /*extends AppIntegrationEngine<String> */{

    public StandaloneAppIntegrationEngine() {
//        this.registerContextProvider("properties", new PropertiesContextProvider());
//        this.registerContextProvider("test", new TestContextProvider());
//
//        this.registerResourceLoader("classloader", new SystemResourceLoader());
//        this.registerResourceLoader("http", new HttpResourceLoader());
    }
}
