package com.alexanderberndt.appintegration.core.impl;

import org.junit.jupiter.api.Test;

public class JettyTestIT {


    @Test
    public void testAll() throws Exception {

//        Server server = new Server(8080);
//        server.setHandler(new HelloHandler());
//
//        server.start();

        //HttpDownloadUtil task = new HttpDownloadUtil();
        //task.execute();

        //Thread.sleep(8000);
//
//
//
//
//
//
//
//
//        server.stop();

    }



}
