package com.alexanderberndt.appintegration.aem.engine;

import com.alexanderberndt.appintegration.aem.engine.models.SlingApplicationInstance;
import com.alexanderberndt.appintegration.engine.ContextProvider;

public interface AemContextProvider extends ContextProvider<SlingApplicationInstance> {
}
