package com.alexanderberndt.appintegration.engine.logging;

public enum LogStatus {INFO, WARNING, ERROR, FAILED}
