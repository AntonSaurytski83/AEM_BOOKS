package to.adapt.junit5demo;

/**
 * Example service
 */
public interface MyService {

  // not methods

}
