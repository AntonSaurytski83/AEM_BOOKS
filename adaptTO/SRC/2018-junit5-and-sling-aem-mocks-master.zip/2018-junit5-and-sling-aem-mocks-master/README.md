adaptTo() 2018 - Junit 5 and Sling/AEM Mocks
============================================

Demo code for talk at adaptTo() 2018:<br/>
https://adapt.to/2018/en/schedule/junit-5-and-sling-aem-mocks.html


Requirements
------------

* Java 8
* Maven 3.3.9
