#!/bin/bash
source /home/.virtualenvs/py36/bin/activate
make ci
