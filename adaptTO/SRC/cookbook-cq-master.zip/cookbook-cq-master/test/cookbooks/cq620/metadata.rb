name    'cq620'
version '0.0.1'

depends 'cq'
