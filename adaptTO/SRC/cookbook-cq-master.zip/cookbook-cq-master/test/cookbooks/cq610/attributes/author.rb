default['cq']['author']['run_mode'] = 'aem61,author,kitchen'
